package com.arcxos.launcher

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = WebViewClient()
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    // Tombol Home ditekan saat launcher sudah terbuka
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.hasCategory(Intent.CATEGORY_HOME) == true) {
            web.evaluateJavascript("window.onHome&&onHome()", null)
        }
    }

    // Launcher tidak boleh "keluar" saat tombol Back ditekan
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    private fun start(intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runOnUiThread {
                try { startActivity(intent) } catch (e: Exception) { }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun category(cat: String): Intent =
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, cat)

    inner class Bridge {

        @JavascriptInterface
        fun listApps(): String {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val seen = HashSet<String>()
            val arr = JSONArray()
            pm.queryIntentActivities(q, 0)
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach {
                    val pkg = it.activityInfo.packageName
                    if (pkg != packageName && seen.add(pkg)) {
                        arr.put(
                            JSONObject()
                                .put("n", it.loadLabel(pm).toString())
                                .put("p", pkg)
                        )
                    }
                }
            return arr.toString()
        }

        @JavascriptInterface
        fun launch(pkg: String): Boolean {
            val li = packageManager.getLaunchIntentForPackage(pkg) ?: return false
            return start(li)
        }

        @JavascriptInterface
        fun system(kind: String): Boolean {
            val intent: Intent = when (kind) {
                "telp" -> Intent(Intent.ACTION_DIAL)
                "sms" -> category(Intent.CATEGORY_APP_MESSAGING)
                "kamera" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                "galeri" -> category(Intent.CATEGORY_APP_GALLERY)
                "calc" -> category(Intent.CATEGORY_APP_CALCULATOR)
                "musik" -> category(Intent.CATEGORY_APP_MUSIC)
                "cfg" -> Intent(Settings.ACTION_SETTINGS)
                "jam" -> Intent(AlarmClock.ACTION_SHOW_ALARMS)
                "home" -> Intent(Settings.ACTION_HOME_SETTINGS)
                else -> return false
            }
            return start(intent)
        }

        @JavascriptInterface
        fun device(): String = "${Build.MANUFACTURER} ${Build.MODEL}"
    }
}
